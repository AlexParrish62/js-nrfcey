
module.exports = {
  ownerID: "292690616285134850",
  mainGuildID: "397479560876261377",
  premiumRole: "476467857543266316",
  color: 0x9590EE,
  typing: "<a:typing:485594750871928833>",
  crossmark: "<a:animatedcrossmark:519166256214048769>",
  checkmark: "<a:animatedcheckmark:519166152488910850>"
};
