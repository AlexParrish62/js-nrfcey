# Miyako Bot
Miyako is an all-in-one entertainment bot for your Discord Server.

Some example of the the features are (but not limited to)

## Social Economy
Miyako has a first-class support for a social economy system where users earn point as they chat and play some games for bonus points!

Level up messages can be disabled and the whole social economy systen can also be disabled if you don't need it.

Upon invite, levelup messages and the social system are enabled by default.

Feel free to disable them via `m!levelup disable` or `m!social disable`

## Moderation
While Miyako's purpose isn't to be a moderation bot we still have moderation features to be convenient.

- **kick**
- **ban**
- **prune**

and more...

## Fun
Lot of fun commands to keep you entertained with Miyako.

## Anime Reactions
Add some Anime GIFs to spice up your conversations with commands like:

- **hug**
- **slap**
- **kiss**

and more...

## Tsundere
Miyako has a tsundere-like personality for interactions, e.g error messages. And you can enable weeb greetings (`m!weebgreetings enable #channel`) to let Miyako greet new people ;)

And much much more... This is a brief description of the bot and the bot is under active development and it would be hard to keep this list updated, invite the bot and see for yourself!
